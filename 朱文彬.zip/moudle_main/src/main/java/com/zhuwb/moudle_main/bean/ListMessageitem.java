package com.zhuwb.moudle_main.bean;

import java.util.List;

/**
 * @author ZhuWB
 *         创建时间 :2017/11/17 08:31
 */

public class ListMessageitem {


    /**
     * code : 1
     * message : [{"msg_type_name":"承接横机加工","message_id":"591099","message_type":"15","message_user_id":"2592","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:55:04","message_content":"我有7针高速 电脑横机空闲， ，有需要的请点击马上拨打，电话联系我！仁和小区","message_phone":"13758096949","message_ads":"中国浙江省嘉兴市秀洲区嘉洪大道1495#号","message_date":"2017-11-21 09:44:00","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"164098","laud_user_cont":"1","msg_comment_cont":"1","isLaud":"0"},{"msg_type_name":"承接横机加工","message_id":"591100","message_type":"15","message_user_id":"5284","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:55:00","message_content":"7针横机空闲 本地人 自己看机器 需要请联系","message_phone":"15824346500","message_ads":"洪合镇","message_date":"2017-11-21 09:44:17","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"164053","laud_user_cont":"1","msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"招套口","message_id":"591108","message_type":"12","message_user_id":"20333","message_zone_id":"3","message_images":"","message_verify_date":"2017-11-21 09:54:44","message_content":"外发套口，招 16 针套口，有空的请点击马上拨打，电话联系我！","message_phone":"15968369941","message_ads":"中国浙江省嘉兴市桐乡市G320(旧)","message_date":"2017-11-21 09:47:58","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"164489","laud_user_cont":"1","msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接横机加工","message_id":"591126","message_type":"15","message_user_id":"34688","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:54:38","message_content":"我有 357电脑横机空闲， ，有需要的请点击马上拨打，电话联系我！","message_phone":"18069678709","message_ads":"中国浙江省嘉兴市秀洲区寺浜路","message_date":"2017-11-21 09:53:54","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"164020","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接平车加工","message_id":"591127","message_type":"20","message_user_id":"25653","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:54:35","message_content":"专业承接平车加工，可踩花边，订商标，拷边，贴口袋，上衬衫领子，等等，有外发平车加工的各位老板、老板娘请点击马上拨打，直接电话联系我！有六个专业大厂出来的工人.北市场旁有活请来电","message_phone":"18768560621","message_ads":"中国浙江省嘉兴市秀洲区洪运路60号","message_date":"2017-11-21 09:54:06","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"164020","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接横机加工","message_id":"591110","message_type":"15","message_user_id":"27529","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:54:20","message_content":"我有357针电脑横机马上空闲自家人看机有需要的请联系我","message_phone":"18268416818","message_ads":"中国浙江省嘉兴市秀洲区","message_date":"2017-11-21 09:48:41","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"163505","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接横机加工","message_id":"591111","message_type":"15","message_user_id":"19824","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:54:15","message_content":"我有 7针 电脑横机空闲， ，有需要的请点击马上拨打，电话联系我！","message_phone":"15967334733","message_ads":"中国浙江省嘉兴市秀洲区国贸路","message_date":"2017-11-21 09:48:45","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"163429","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接横机加工","message_id":"591123","message_type":"15","message_user_id":"2190","message_zone_id":"2","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121095337756_115.png787311295","message_verify_date":"2017-11-21 09:54:12","message_content":"我有8台12针双系统 电脑横机空闲， ，有需要的请点击马上拨打，电话联系我！","message_phone":"13758060669","message_ads":"中国浙江省嘉兴市秀洲区","message_date":"2017-11-21 09:53:35","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"163132","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"求购","message_id":"591102","message_type":"44","message_user_id":"35030","message_zone_id":"2","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121094550183_115.png787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121094550926_115.png787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121094551326_115.png787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121094552359_115.png787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/bobaoge20171121/20171121094552378_115.png787311295","message_verify_date":"2017-11-21 09:53:50","message_content":"我要求购 ，有此类商品的商家或朋友请点击马上拨打，直接电话联系我！","message_phone":"18578775186","message_ads":"中国浙江省嘉兴市秀洲区富民路463号","message_date":"2017-11-21 09:45:47","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"140532","laud_user_cont":"1","msg_comment_cont":0,"isLaud":"0"},{"msg_type_name":"承接绣花加工","message_id":"591103","message_type":"19","message_user_id":"43333","message_zone_id":"2","message_images":"","message_verify_date":"2017-11-21 09:53:38","message_content":"专业承接电脑绣花加工，有外发绣花加工的毛衣厂、门店老板、老板娘请点击马上拨打，直接电话联系我！","message_phone":"18357304067","message_ads":"中国浙江省嘉兴市秀洲区","message_date":"2017-11-21 09:46:03","message_reason":null,"message_state":"1","message_hongbao_state":"1","brow_user_cont":"139142","laud_user_cont":0,"msg_comment_cont":0,"isLaud":"0"}]
     */

    private int code;
    private List<MessageBean> message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<MessageBean> getMessage() {
        return message;
    }

    public void setMessage(List<MessageBean> message) {
        this.message = message;
    }

    public static class MessageBean {
        /**
         * msg_type_name : 承接横机加工
         * message_id : 591099
         * message_type : 15
         * message_user_id : 2592
         * message_zone_id : 2
         * message_images :
         * message_verify_date : 2017-11-21 09:55:04
         * message_content : 我有7针高速 电脑横机空闲， ，有需要的请点击马上拨打，电话联系我！仁和小区
         * message_phone : 13758096949
         * message_ads : 中国浙江省嘉兴市秀洲区嘉洪大道1495#号
         * message_date : 2017-11-21 09:44:00
         * message_reason : null
         * message_state : 1
         * message_hongbao_state : 1
         * brow_user_cont : 164098
         * laud_user_cont : 1
         * msg_comment_cont : 1
         * isLaud : 0
         */

        private String msg_type_name;
        private String message_id;
        private String message_type;
        private String message_user_id;
        private String message_zone_id;
        private String message_images;
        private String message_verify_date;
        private String message_content;
        private String message_phone;
        private String message_ads;
        private String message_date;
        private Object message_reason;
        private String message_state;
        private String message_hongbao_state;
        private String brow_user_cont;
        private String laud_user_cont;
        private String msg_comment_cont;
        private String isLaud;

        public String getMsg_type_name() {
            return msg_type_name;
        }

        public void setMsg_type_name(String msg_type_name) {
            this.msg_type_name = msg_type_name;
        }

        public String getMessage_id() {
            return message_id;
        }

        public void setMessage_id(String message_id) {
            this.message_id = message_id;
        }

        public String getMessage_type() {
            return message_type;
        }

        public void setMessage_type(String message_type) {
            this.message_type = message_type;
        }

        public String getMessage_user_id() {
            return message_user_id;
        }

        public void setMessage_user_id(String message_user_id) {
            this.message_user_id = message_user_id;
        }

        public String getMessage_zone_id() {
            return message_zone_id;
        }

        public void setMessage_zone_id(String message_zone_id) {
            this.message_zone_id = message_zone_id;
        }

        public String getMessage_images() {
            return message_images;
        }

        public void setMessage_images(String message_images) {
            this.message_images = message_images;
        }

        public String getMessage_verify_date() {
            return message_verify_date;
        }

        public void setMessage_verify_date(String message_verify_date) {
            this.message_verify_date = message_verify_date;
        }

        public String getMessage_content() {
            return message_content;
        }

        public void setMessage_content(String message_content) {
            this.message_content = message_content;
        }

        public String getMessage_phone() {
            return message_phone;
        }

        public void setMessage_phone(String message_phone) {
            this.message_phone = message_phone;
        }

        public String getMessage_ads() {
            return message_ads;
        }

        public void setMessage_ads(String message_ads) {
            this.message_ads = message_ads;
        }

        public String getMessage_date() {
            return message_date;
        }

        public void setMessage_date(String message_date) {
            this.message_date = message_date;
        }

        public Object getMessage_reason() {
            return message_reason;
        }

        public void setMessage_reason(Object message_reason) {
            this.message_reason = message_reason;
        }

        public String getMessage_state() {
            return message_state;
        }

        public void setMessage_state(String message_state) {
            this.message_state = message_state;
        }

        public String getMessage_hongbao_state() {
            return message_hongbao_state;
        }

        public void setMessage_hongbao_state(String message_hongbao_state) {
            this.message_hongbao_state = message_hongbao_state;
        }

        public String getBrow_user_cont() {
            return brow_user_cont;
        }

        public void setBrow_user_cont(String brow_user_cont) {
            this.brow_user_cont = brow_user_cont;
        }

        public String getLaud_user_cont() {
            return laud_user_cont;
        }

        public void setLaud_user_cont(String laud_user_cont) {
            this.laud_user_cont = laud_user_cont;
        }

        public String getMsg_comment_cont() {
            return msg_comment_cont;
        }

        public void setMsg_comment_cont(String msg_comment_cont) {
            this.msg_comment_cont = msg_comment_cont;
        }

        public String getIsLaud() {
            return isLaud;
        }

        public void setIsLaud(String isLaud) {
            this.isLaud = isLaud;
        }
    }
}
