package com.zhuwb.moudle_main.bean;

import java.util.List;

/**
 * @author ZhuWB
 *         创建时间 :2017/11/15 09:31
 */

public class BannerMessage {


    /**
     * code : 1
     * message : [{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner35.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":"5","message_user_id":"1","message_zone_id":0,"message_type":0,"message_master":"","cost_type_id":"1","message_images":"","message_phone":"13112341234","message_verify_date":"2017-11-07 18:43:27","message_date":"2017-11-07 18:43:27","message_content":"sdasdasdasd","message_ads":"adsdsdsa","message_state":1,"advmsg_reason":null,"message_hongbao_state":1,"brow_user_cont":"0","laud_user_cont":0,"isLaud":0,"isAdv":1,"point":["黄金会员,实名认证,5千保证金,第1年认证"],"cerMessage":{"head":"","cer_user_nickname":""},"numbers":null},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner21.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner23.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner20.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner36.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/ban8.jpg","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner34.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner25.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0},{"msg_type_name":"推广信息","message_id":0,"message_user_id":0,"message_zone_id":0,"cost_type_id":0,"message_type":0,"message_ads":"播报哥","message_phone":null,"message_master":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner27.jpg?v=1.7","message_images":"http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295","message_verify_date":"2017-11-15 09:43:32","message_content":"播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击\u201c消息推广\u201d试试吧！","advmsg_reason":0,"message_state":0,"laud_user_cont":0,"message_hongbao_state":1,"brow_user_cont":0,"isLaud":0,"isAdv":1,"numbers":0}]
     */

    private int code;
    private List<BannerBean> message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<BannerBean> getMessage() {
        return message;
    }

    public void setMessage(List<BannerBean> message) {
        this.message = message;
    }

    public static class BannerBean {
        /**
         * msg_type_name : 推广信息
         * message_id : 0
         * message_user_id : 0
         * message_zone_id : 0
         * cost_type_id : 0
         * message_type : 0
         * message_ads : 播报哥
         * message_phone : null
         * message_master : http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner35.jpg?v=1.7
         * message_images : http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner30.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner31.jpg?v=2.2787311295http://bobaoge.oss-cn-shanghai.aliyuncs.com/adv/banner32.jpg?v=2.2787311295
         * message_verify_date : 2017-11-15 09:43:32
         * message_content : 播报哥3.1来啦！投放广告,右上角就会出现您的联系电话,可以马上拨打！快去首页点击“消息推广”试试吧！
         * advmsg_reason : 0
         * message_state : 0
         * laud_user_cont : 0
         * message_hongbao_state : 1
         * brow_user_cont : 0
         * isLaud : 0
         * isAdv : 1
         * numbers : 0
         * message_date : 2017-11-07 18:43:27
         * point : ["黄金会员,实名认证,5千保证金,第1年认证"]
         * cerMessage : {"head":"","cer_user_nickname":""}
         */

        private String msg_type_name;
        private int message_id;
        private int message_user_id;
        private int message_zone_id;
        private int cost_type_id;
        private int message_type;
        private String message_ads;
        private Object message_phone;
        private String message_master;
        private String message_images;
        private String message_verify_date;
        private String message_content;
        private int advmsg_reason;
        private int message_state;
        private int laud_user_cont;
        private int message_hongbao_state;
        private int brow_user_cont;
        private int isLaud;
        private int isAdv;
        private int numbers;
        private String message_date;
        private CerMessageBean cerMessage;
        private List<String> point;

        public String getMsg_type_name() {
            return msg_type_name;
        }

        public void setMsg_type_name(String msg_type_name) {
            this.msg_type_name = msg_type_name;
        }

        public int getMessage_id() {
            return message_id;
        }

        public void setMessage_id(int message_id) {
            this.message_id = message_id;
        }

        public int getMessage_user_id() {
            return message_user_id;
        }

        public void setMessage_user_id(int message_user_id) {
            this.message_user_id = message_user_id;
        }

        public int getMessage_zone_id() {
            return message_zone_id;
        }

        public void setMessage_zone_id(int message_zone_id) {
            this.message_zone_id = message_zone_id;
        }

        public int getCost_type_id() {
            return cost_type_id;
        }

        public void setCost_type_id(int cost_type_id) {
            this.cost_type_id = cost_type_id;
        }

        public int getMessage_type() {
            return message_type;
        }

        public void setMessage_type(int message_type) {
            this.message_type = message_type;
        }

        public String getMessage_ads() {
            return message_ads;
        }

        public void setMessage_ads(String message_ads) {
            this.message_ads = message_ads;
        }

        public Object getMessage_phone() {
            return message_phone;
        }

        public void setMessage_phone(Object message_phone) {
            this.message_phone = message_phone;
        }

        public String getMessage_master() {
            return message_master;
        }

        public void setMessage_master(String message_master) {
            this.message_master = message_master;
        }

        public String getMessage_images() {
            return message_images;
        }

        public void setMessage_images(String message_images) {
            this.message_images = message_images;
        }

        public String getMessage_verify_date() {
            return message_verify_date;
        }

        public void setMessage_verify_date(String message_verify_date) {
            this.message_verify_date = message_verify_date;
        }

        public String getMessage_content() {
            return message_content;
        }

        public void setMessage_content(String message_content) {
            this.message_content = message_content;
        }

        public int getAdvmsg_reason() {
            return advmsg_reason;
        }

        public void setAdvmsg_reason(int advmsg_reason) {
            this.advmsg_reason = advmsg_reason;
        }

        public int getMessage_state() {
            return message_state;
        }

        public void setMessage_state(int message_state) {
            this.message_state = message_state;
        }

        public int getLaud_user_cont() {
            return laud_user_cont;
        }

        public void setLaud_user_cont(int laud_user_cont) {
            this.laud_user_cont = laud_user_cont;
        }

        public int getMessage_hongbao_state() {
            return message_hongbao_state;
        }

        public void setMessage_hongbao_state(int message_hongbao_state) {
            this.message_hongbao_state = message_hongbao_state;
        }

        public int getBrow_user_cont() {
            return brow_user_cont;
        }

        public void setBrow_user_cont(int brow_user_cont) {
            this.brow_user_cont = brow_user_cont;
        }

        public int getIsLaud() {
            return isLaud;
        }

        public void setIsLaud(int isLaud) {
            this.isLaud = isLaud;
        }

        public int getIsAdv() {
            return isAdv;
        }

        public void setIsAdv(int isAdv) {
            this.isAdv = isAdv;
        }

        public int getNumbers() {
            return numbers;
        }

        public void setNumbers(int numbers) {
            this.numbers = numbers;
        }

        public String getMessage_date() {
            return message_date;
        }

        public void setMessage_date(String message_date) {
            this.message_date = message_date;
        }

        public CerMessageBean getCerMessage() {
            return cerMessage;
        }

        public void setCerMessage(CerMessageBean cerMessage) {
            this.cerMessage = cerMessage;
        }

        public List<String> getPoint() {
            return point;
        }

        public void setPoint(List<String> point) {
            this.point = point;
        }

        public static class CerMessageBean {
            /**
             * head :
             * cer_user_nickname :
             */

            private String head;
            private String cer_user_nickname;

            public String getHead() {
                return head;
            }

            public void setHead(String head) {
                this.head = head;
            }

            public String getCer_user_nickname() {
                return cer_user_nickname;
            }

            public void setCer_user_nickname(String cer_user_nickname) {
                this.cer_user_nickname = cer_user_nickname;
            }
        }
    }
}
